public enum Genero {
    ROCK, POP, OPERA, CLASICA, JAZZ, ELECTRONICA
}
