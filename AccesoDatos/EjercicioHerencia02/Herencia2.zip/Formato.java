public enum Formato {
    WAV, MP3, MIDI, AVI, MOV, MPG, CDAUDIO, DVD
}
